% ITEC460 PROJECT 1
% Test Data
% Iris Plants Database
% Attribute Information:
%   1. sepal length in cm
%   2. sepal width in cm
%   3. petal length in cm
%  4. petal width in cm

tst_data=[
5	3.5	1.3	0.3	;
4.5	2.3	1.3	0.3	;
4.4	3.2	1.3	0.2	;
5	3.5	1.6	0.6	;
5.1	3.8	1.9	0.4	;
4.8	3	1.4	0.3	;
5.1	3.8	1.6	0.2	;
4.6	3.2	1.4	0.2	;
5.3	3.7	1.5	0.2	;
5	3.3	1.4	0.2	;
6.7	3.1	5.6	2.4	;
6.9	3.1	5.1	2.3	;
5.8	2.7	5.1	1.9	;
6.8	3.2	5.9	2.3	;
6.7	3.3	5.7	2.5	;
6.7	3	5.2	2.3	;
6.3	2.5	5	1.9	;
6.5	3	5.2	2	;
6.2	3.4	5.4	2.3	;
5.9	3	5.1	1.8	];
