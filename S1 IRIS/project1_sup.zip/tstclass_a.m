% ITEC460 PROJECT 1
% Test Data Classes
% Iris Plants Database
% class: 
%   -- Iris Setosa      [1 0 0]
%   -- Iris Versicolour [0 1 0]
%   -- Iris Virginica   [0 0 1]

tst_class=[
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
1, 0, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 1, 0 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
0, 0, 1 ;
];
